# pharmacy-locator

Partie Backend du projet : localisation des pharmacies via JEE en utilisant SpringBoot

Diagramme de classe : 



![image](https://user-images.githubusercontent.com/87018618/207067378-168492aa-30d0-48fb-8b99-0fbb37690ac5.png)


